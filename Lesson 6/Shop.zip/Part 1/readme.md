<h1><strong>MySixthJsLesson</strong> <br>Lesson 6</h1>

<p>
	<img src="https://pp.userapi.com/c837629/v837629008/3b890/jYgGpTkpXBA.jpg" alt="firtsjs">
</p>

<p>Author: <a href="https://vk.com/id180091008" target="_blank">Artem Chernii</a></p>
